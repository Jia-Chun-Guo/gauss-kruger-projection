﻿#pragma once

#include <cmath>
#include <cstdint>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>

#include <boost/math/constants/constants.hpp>
#include <boost/multiprecision/cpp_bin_float.hpp>
#include <boost/multiprecision/cpp_complex.hpp>

namespace gmath {

    // =========================================================
    // High-precision real number type
    // =========================================================
    using complex = boost::multiprecision::cpp_complex_100;
    using real = complex::value_type;
    using boost::multiprecision::sqrt;

    // =========================================================
    // High-precision PI
    // =========================================================
    inline const real PI = boost::math::constants::pi<real>();
    // GRS80 Ellipsoid Parameters
    // Semi-major axis (meters)a = 6378137.0
    // Flattening = (1 / 298.257222101)
    // First eccentricity squared e² = f (2 − f)
    inline const real a = real("6378137.0");
    inline const real f = real(1) / real("298.257222101");
    inline const real e = sqrt(f * (real(2) - f));
    inline const real ep = real(1) - f;   // ep = sqrt(1 - e^2) = 1 - f;
    inline const real e2 = f * (real(2) - f); //e2=e^2;
    inline const real n = f / (real(2) - f);
    inline const real n2 = n * n;

    // =================== DMS parser ===================
    inline bool read_dms_space(real& deg_out)
    {
        real D = 0, M = 0, S = 0;

        std::string line;
        std::getline(std::cin >> std::ws, line);

        std::stringstream ss(line);
        std::vector<real> v;
        real x;

        while (ss >> x) {
            v.push_back(x);
        }

        if (v.empty() || v.size() > 3)
            return false;

        D = v[0];
        if (v.size() >= 2) M = v[1];
        if (v.size() == 3) S = v[2];

        using boost::multiprecision::abs;
        if (abs(M) >= real(60) || abs(S) >= real(60))
            return false;

        real sign = (D < real(0)) ? real(-1) : real(1);
        deg_out = sign * (abs(D) + abs(M) / real(60) + abs(S) / real(3600));

        return true;
    }
    
    // =========================================================
    // Degree ↔ Radian
    // =========================================================
    inline real deg_to_rad(real deg) {
        return deg * PI / real(180);
    }

    inline real rad_to_deg(real rad) {
        return rad * real(180) / PI;
    }

    // =========================================================
    // Convert DMS → degree
    // One negative input makes the entire angle negative
    // =========================================================
    inline real dms_to_deg(real d, real m, real s) {
        using boost::multiprecision::abs;

        real sign = (d < 0 || m < 0 || s < 0) ? real(-1) : real(1);
        return sign * (abs(d) + abs(m) / real(60) + abs(s) / real(3600));
    }

    // =========================================================
    // Normalize longitude or azimuth (radians) to the range (-π, π]
    // Use multiprecision floor()
    // =========================================================
    inline real normalize_lon_azi_rad(real lon_rad)
    {
        using boost::multiprecision::floor;

        const real two_pi = real(2) * PI;

        // First normalize into [0, 2π)
        lon_rad -= floor(lon_rad / two_pi) * two_pi;

        // Then map into (-π, π]
        if (lon_rad <= -PI)
            lon_rad += two_pi;
        else if (lon_rad > PI)
            lon_rad -= two_pi;

        return lon_rad;
    }

    // =========================================================
    // Generic sign function: returns -1, 0, +1
    // =========================================================
    template <typename T>
    inline int sign(const T& x) {
        return (T(0) < x) - (x < T(0));
    }

} // namespace gmath
