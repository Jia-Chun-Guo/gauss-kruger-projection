// ============================================================================
// Numerical verification program for the computation of Gauss�CKr��ger (GK)
// coordinates, comparing the following methods:
//
// (1) Lee��s exact formulation (Lee, 1962), Eqs. (20)�C(21);
// (2) New complex-analytic definition proposed in this paper, Eq. (37);
// (3) Nome-q series expansion (Guo et al., 2020), Eq. (42);
// (4) Classical Kr��ger�Cn series implementation (Karney, 2011).
//
// The program is intended for numerical validation and accuracy comparison
// of different GK projection formulations.
//
// All computations are performed using high-precision arithmetic based on
// Boost.Multiprecision to minimize numerical round-off errors.
//
// Notes:
// (1) This program does not support projection over the entire domain D
//     defined in Eq. (5).
// (2) Coordinate accuracy is better than the nanometer level only within
//     the longitude interval [-35��, 35��].
// ============================================================================
//
// Copyright (c) 2025, Anhui Jianzhu University, China
// Authors: Jia-Chun Guo, Nico Sneeuw, Shao-Feng Bian, and Yi Liu
// Contact: jchguo@ahjzu.edu.cn
//
// License: This source code is released under the MIT License.
//          https://opensource.org/licenses/MIT
// ============================================================================

// =================== includes ===================
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
#include <sstream>
#include <vector>

#include <boost/math/special_functions/ellint_1.hpp>
#include <boost/math/special_functions/ellint_2.hpp>
#include <boost/math/special_functions/ellint_3.hpp>
#include <boost/math/special_functions/jacobi.hpp>
#include <boost/math/special_functions/jacobi_elliptic.hpp>

#include "GeneralMath.hpp"
#include "GK_proj_Core.hpp"

// For brevity
using std::cout;
using std::cin;
using std::string;
using gmath::real;
using gmath::complex;

//using namespace boost::math
using boost::math::ellint_1;
using boost::math::ellint_2;

using boost::multiprecision::sin;
using boost::multiprecision::cos;
using boost::multiprecision::atan2;
using boost::multiprecision::sqrt;
using boost::multiprecision::abs;
using boost::multiprecision::atanh;

using gmath::PI;
using gmath::a;
using gmath::e;
using gmath::ep;
using gmath::e2;
using gmath::n;
using gmath::n2;
using gmath::read_dms_space;
using gmath::deg_to_rad;
using gmath::rad_to_deg;
using gmath::sign;

using GK_proj::sn;
using GK_proj::cn;
using GK_proj::dn;
using GK_proj::cd;
using GK_proj::cs;
using GK_proj::dc;
using GK_proj::ds;
using GK_proj::nc;
using GK_proj::nd;
using GK_proj::ns;
using GK_proj::sc;
using GK_proj::sd;

using GK_proj::FK;
using GK_proj::FE;
using GK_proj::phic_prime;
using GK_proj::GK_kruger_n_series;
using GK_proj::zeta_by_series;
using GK_proj::GK_q_series;
using GK_proj::scale;
using GK_proj::convergence;

// =======================================================================
//                                  MAIN
// =======================================================================
int main() {

    while (true) {

        system("cls");
        cout << "===== GK projection Calculator (Boost high precision) =====\n";
        cout << "Choose input method:\n"
            << "1 = decimal degrees\n"
            << "2 = degrees-minutes-seconds (DMS)\n"
            << "q = quit\n\n";

        string cmd;
        cin >> cmd;

        // ========================
        // COMMAND VALIDATION
        // ========================
        if (cmd != "1" && cmd != "2" && cmd != "q" && cmd != "Q")
        {
            cout << "Invalid input. Please enter 1, 2, or q to quit.\n";
            cout << "Press ENTER to continue...";
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            cin.get();
            continue;
        }

        if (cmd == "q" || cmd == "Q")
            break;

        int method = 0;
        try {
            method = std::stoi(cmd);
        }
        catch (...) {
            cout << "Invalid input. Press ENTER...\n";
            cin.ignore();
            cin.get();
            continue;
        }

        real lat_deg, dlon_deg;

        // ========================
        // INPUT
        // ========================
        if (method == 1) {

            cout << "Enter Latitude (deg [-90, 90], e.g.20.5): ";
            cin >> lat_deg;

            cout << "Enter D_Longitude (deg [-35, 35], e.g.-30.6): ";
            cin >> dlon_deg;

        }
        else if (method == 2) {

            cout << "Enter Latitude (D M S, deg [-90, 90]��e.g. 30 15 20 or -45 30): ";
            if (!read_dms_space(lat_deg)) {
                cout << "ERROR: invalid D M S input (M,S must be < 60)\nPress ENTER...";
                cin.get();
                continue;
            }

            cout << "Enter D_Longitude1 (D M S, deg [-35, 35], e.g. 15 30 or -18): ";
            if (!read_dms_space(dlon_deg)) {
                cout << "ERROR: invalid D M S input (M,S must be < 60)\nPress ENTER...";
                cin.get();
                continue;
            }

        }

        // ========================
        // VALIDITY CHECK
        // ========================
        if (!(lat_deg >= real(-90) && lat_deg <= real(90))) {
            cout << "ERROR: latitude must be in [-90��, 90��]\nPress ENTER...";
            cin.ignore();
            cin.get();
            continue;
        }

        if (!(dlon_deg >= real(-180) && dlon_deg <= real(180))) {
            cout << "ERROR: longitude must be in [-180��, 180��]\nPress ENTER...";
            cin.ignore();
            cin.get();
            continue;
        }

        // ========================
        // CONVERT TO RADIANS
        // ========================
        real lat = deg_to_rad(lat_deg);
        real dlon = deg_to_rad(dlon_deg);

        real u, v, psi, xi, eta, phi, phip;
        real u2, v2, phi2, phip2;
        real xL, yL, xN, yN, k, gamma;
        complex phic2, w, w2, zq, zK;

        if (lat_deg == real(90) || lat_deg == real(-90))
        {
            xL = sign(lat_deg) * a * (ellint_2(e));
            yL = real(0);
            xN = xL;
            yN = real(0);
            zq = complex(xL, real(0));
            zK = complex(xL, real(0));

            k = real(1);
            gamma = real(0);
        }
        else if (lat_deg == real(0))
        {
            w = FK(e) * zeta_by_series(lat, dlon, e);
            u = w.real();
            v = w.imag();
            
            xL = real(0);
            yL = a * dlon;
            xN = real(0);
            yN = yL;
            zq = complex(real(0), yL);
            zK = complex(real(0), yL);

            k = nd(ep, v);
            gamma = real(0);
        }
        else
        {
            //psi = atanh(sin(lat)) - e * atanh(e * sin(lat));
            //phic2 = phic_prime(lat, dlon, e);
            //xi = phic2.real();
            //eta = phic2.imag();

            w = FK(e) * zeta_by_series(lat, dlon, e);
            u = w.real();
            v = w.imag();

            //*==Calculations of GK coordinates:==*//
            //*==Method 1 Lee's exat method:==*//
            //*==Via Lee's exact method, Lee(1962), Eqs.(20) and (21).==*//
            phi = atan2(sn(e, u), cn(e, u));
            phip = atan2(sn(ep, v), cn(ep, v));

            xL = a * (ellint_2(e, phi) -
                (e2 * sn(e, u) * cn(e, u) * dn(e, u))
                / (dn(e, u) * dn(e, u) + dn(ep, v) * dn(ep, v) - real(1)));
            yL = a * (v - ellint_2(ep, phip) +
                ((real(1) - e2) * sn(ep, v) * cn(ep, v) * dn(ep, v))
                / (dn(e, u) * dn(e, u) + dn(ep, v) * dn(ep, v) - real(1)));

            //*===Method 2: New definition 2,  ==*//
            // Eq.(37) in this submitted paper:==*//
            w2 = ellint_1(e) - w;
            u2 = w2.real();
            v2 = w2.imag();
            phi2 = atan2(sn(e, u2), cn(e, u2));
            phip2 = atan2(sn(ep, v2), cn(ep, v2));

            xN = a * (ellint_2(e) - ellint_2(e, phi2) +
                (e2 * sn(e, u2) * cn(e, u2) * dn(e, u2))
                / (dn(e, u2) * dn(e, u2) - ns(ep, v2) * ns(ep, v2)));
            yN = a * (-v2 + ellint_2(ep, phip2) -
                (sn(ep, v2) * cn(ep, v2) * dn(ep, v2))
                / (nd(e, u2) * nd(e, u2) - sn(ep, v2) * sn(ep, v2)));

            //*===Method 3 nome_q_series, ==*//
            //*==Guo et al (2020), Eq.(42)==*//
            zq = GK_q_series(lat, dlon, e);
            //real xq = zq.real();
            //real yq = zq.imag();

            //*==Method 4 Kruger_n_series, see Karney(2011).==*//
            zK = GK_kruger_n_series(lat, dlon, e);
            //real xK = zK.real();
            //real yK = zK.imag();

            //*===========Calculating of scale and convergence:==========*//
            //*==Via Lee's exact method, Lee(1963), Eqs.(56) and (57).:==*//
            k = scale(lat, u, v, e);
            gamma = convergence(lat, u, v, e);
        }

        // ========================
        // PRINT RESULTS
        // ========================
        cout << "\n======== RESULTS ========\n";
        cout << "\nComplex GK coordinates of this point (meters):\n\n";

        std::cout << std::fixed << std::setprecision(14)
            << " zGK_L = " << xL << " + i* " << yL << "  // Via Lee's exact method, Lee(1962), Eqs.(20)-(21)." << "\n" << "\n"
            << " zGK_N = " << xN << " + i* " << yN << "  // Via New definition, Eq.(37) in this submitted paper." << "\n" << "\n"
            << " zGK_q = " << zq.real() << " + i* " << zq.imag() << "  // Via Nome-q series, Guo et al (2020), Eq.(42)." << "\n" << "\n"
            << " zGK_K = " << zK.real() << " + i* " << zK.imag() << "  // Via Kruger-n series, see Karney(2011)." << "\n";

        cout << "\nScale and Convergence: \n\n";
        std::cout << std::fixed << std::setprecision(14)
            << " k = " << k << ", "
            << " �� = " << real(180) * gamma / PI << " deg. // Via Lee's exact method, Lee(1963), Eqs.(56)-(57)." << "\n" << "\n";
        cout << "-------------------------\n";
        
        cout << "Notes:" << "\n" 
             << "  (1) This program does not support projection over the entire domain D, defined in Eq.(5);\n";
        cout << "  (2) Coordinate accuracy is better than the nanometer level only within longitude interval [-35deg, 35deg].\n";
        cout << "\nPress ENTER to continue...";
        cin.ignore();
        cin.get();
    }

    cout << "Program exited.\n";
    return 0;
}
