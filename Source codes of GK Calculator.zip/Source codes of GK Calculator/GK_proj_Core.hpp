#pragma once

#include "GeneralMath.hpp"

#include <boost/math/special_functions/ellint_1.hpp>
#include <boost/math/special_functions/ellint_2.hpp>
#include <boost/math/special_functions/ellint_3.hpp>
#include <boost/math/special_functions/jacobi.hpp>
#include <boost/math/special_functions/jacobi_elliptic.hpp>
#include <initializer_list>

namespace GK_proj {

    using gmath::real;
    using gmath::complex;
    using gmath::PI;
    using gmath::a;
    using gmath::e;
    using gmath::ep;
    using gmath::e2;
    using gmath::n;
    using gmath::n2;
   
    using boost::math::ellint_1;
    using boost::math::ellint_2;
    using boost::math::ellint_3;

    using boost::multiprecision::sin;
    using boost::multiprecision::cos;
    using boost::multiprecision::atan2;
    using boost::multiprecision::sqrt;
    using boost::multiprecision::abs;
    using boost::multiprecision::atanh;

    // ========================
    // Wrappers of Jacobi elliptic functions.
    // ========================
    inline real sn(real k, real u) {
        return (boost::math::jacobi_sn(k, u));
    }
    inline real cn(real k, real u) {
        return (boost::math::jacobi_cn(k, u));
    }
    inline real dn(real k, real u) {
        return (boost::math::jacobi_dn(k, u));
    }
    inline real cd(real k, real u) {
        return (boost::math::jacobi_cd(k, u));
    }
    inline real cs(real k, real u) {
        return (boost::math::jacobi_cs(k, u));
    }
    inline real dc(real k, real u) {
        return (boost::math::jacobi_dc(k, u));
    }
    inline real ds(real k, real u) {
        return (boost::math::jacobi_ds(k, u));
    }
    inline real nc(real k, real u) {
        return (boost::math::jacobi_nc(k, u));
    }
    inline real nd(real k, real u) {
        return (boost::math::jacobi_nd(k, u));
    }
    inline real ns(real k, real u) {
        return (boost::math::jacobi_ns(k, u));
    }
    inline real sc(real k, real u) {
        return (boost::math::jacobi_sc(k, u));
    }
    inline real sd(real k, real u) {
        return (boost::math::jacobi_sd(k, u));
    }

    // ========================
    // Kahan compensated summation for real numbers.
    // Reduces loss of significance in summing series terms.
    // ========================
    inline real KahanSumReal(std::initializer_list<real> v)
    {
        real sum = real(0);
        real c = real(0);

        for (const real& x : v) {
            const real y = x - c;
            const real t = sum + y;
            c = (t - sum) - y;
            sum = t;
        }
        return sum;
    }

    // ========================
    // Kahan compensated summation for complex numbers (Boost.Multiprecision).
    // ========================
    inline complex KahanSumComplex(std::initializer_list<complex> v)
    {
        complex sum(real(0), real(0));
        complex c(real(0), real(0));

        for (const complex& x : v) {
            const complex y = x - c;
            const complex t = sum + y;
            c = (t - sum) - y;
            sum = t;
        }
        return sum;
    }

    // ========================
    // Normalized complete elliptic integral of the first kind.
    // FK(e) = 2 K(e) / ��.
    // ========================
    inline real FK(real e) {
        return (real(2) * ellint_1(e) / PI);
    }

    // ========================
    // Normalized complete elliptic integral of the second kind.
    // FE(e) = 2 E(e) / ��.
    // ========================
    inline real FE(real e) {
        return (real(2) * ellint_2(e) / PI);
    }
 
    // ========================
    // Complex auxiliary latitude �ա�c = �� + i��,
    // defined from geodetic latitude and longitude difference.
    // See Guo et al. (2020), Eq. (34).
    // ========================
    inline complex phic_prime(
        const real& lat,   // geodetic latitude ��  (radian)
        const real& dlon,  // longitude difference ���� (radian)
        const real& e      // eccentricity
    )
    {
        real psi = atanh(sin(lat)) - e * atanh(e * sin(lat));

        real xi = atan2(sinh(psi), cos(dlon));
        real eta = atanh(sin(dlon) / cosh(psi));

        return complex(xi, eta);
    }

    // ========================
    // Gauss�CKr��ger projection via the classical Kr��ger�Cn series expansion.
    // Used as a reference implementation for numerical comparison.
    // ========================
    inline complex GK_kruger_n_series(
        const real& lat,   // geodetic latitude ��  (radian)
        const real& dlon,  // longitude difference ���� (radian)
        const real& e      // eccentricity
    )
    {
        // a1
        real a1 =
            n * (real(1) / real(2)
                + n * (-real(2) / real(3)
                    + n * (real(5) / real(16)
                        + n * (real(41) / real(180)
                            + n * (-real(127) / real(288)
                                + n * (real(7891) / real(37800)
                                    + n * (real(72161) / real(387072)
                                        + n * (-real("18975107") / real("50803200")
                                            + n * (real("60193001") / real("290304000")
                                                + n * (real("134592031") / real("1026432000")
                                                    + n * (-real("1043934033787") / real("3218890752000")
                                                        + n * (real("1107802529272207") / real("5178390497280000"))
                                                        )))))))))));

        // a2
        real a2 =
            n2 * (real(13) / real(48)
                + n * (-real(3) / real(5)
                    + n * (real(557) / real(1440)
                        + n * (real(281) / real(630)
                            + n * (-real("1983433") / real("1935360")
                                + n * (real("13769") / real("28800")
                                    + n * (real("148003883") / real("174182400")
                                        + n * (-real("705286231") / real("465696000")
                                            + n * (real("1703267974087") / real("3218890752000")
                                                + n * (real("490493610499") / real("373621248000")
                                                    + n * (-real("1975809888712343") / real("976396861440000"))
                                                    ))))))))));

        // a3
        real a3 =
            n * n2 * (real(61) / real(240)
                + n * (-real(103) / real(140)
                    + n * (real("15061") / real("26880")
                        + n * (real("167603") / real("181440")
                            + n * (-real("67102379") / real("29030400")
                                + n * (real("79682431") / real("79833600")
                                    + n * (real("6304945039") / real("2128896000")
                                        + n * (-real("6601904925257") / real("1307674368000")
                                            + n * (real("35472608886503") / real("41845579776000")
                                                + n * (real("7660808256523559") / real("1098446469120000"))
                                                )))))))));

        // a4
        real a4 =
            n2 * n2 * (real("49561") / real("161280")
                + n * (-real("179") / real("168")
                    + n * (real("6601661") / real("7257600")
                        + n * (real("97445") / real("49896")
                            + n * (-real("40176129013") / real("7664025600")
                                + n * (real("138471097") / real("66528000")
                                    + n * (real("48087451385201") / real("5230697472000")
                                        + n * (-real("634613396309") / real("40864824000")
                                            + n * (real("152161926556090753") / real("1124809184378880000"))
                                            ))))))));

        // a5
        real a5 =
            n * n2 * n2 * (real("34729") / real("80640")
                + n * (-real("3418889") / real("1995840")
                    + n * (real("14644087") / real("9123840")
                        + n * (real("2605413599") / real("622702080")
                            + n * (-real("31015475399") / real("2583060480")
                                + n * (real("5820486440369") / real("1307674368000")
                                    + n * (real("98568244458947") / real("3678732288000")
                                        + n * (-real("1367520624030470251") / real("29877743960064000"))
                                        )))))));

        // a6
        real a6 =
            n2 * n2 * n2 * (real("212378941") / real("319334400")
                + n * (-real("30705481") / real("10378368")
                    + n * (real("175214326799") / real("58118860800")
                        + n * (real("870492877") / real("96096000")
                            + n * (-real("1328004581729009") / real("47823519744000")
                                + n * (real("3512873113922087") / real("355687428096000")
                                    + n * (real("986615629722639449") / real("13133074268160000"))
                                    ))))));

        // a7
        real a7 =
            n * n2 * n2 * n2 * (real("1522256789") / real("1383782400")
                + n * (-real("16759934899") / real("3113510400")
                    + n * (real("1315149374443") / real("221405184000")
                        + n * (real("71809987837451") / real("3629463552000")
                            + n * (-real("52653013293696143") / real("812999835648000")
                                + n * (real("101784256296129577") / real("4455864483840000"))
                                )))));

        // a8
        real a8 =
            n2 * n2 * n2 * n2 * (real("1424729850961") / real("743921418240")
                + n * (-real("256783708069") / real("25204608000")
                    + n * (real("2468749292989891") / real("203249958912000")
                        + n * (real("117880637749661") / real("2707556544000")
                            + n * (-real("5921832934345276446697")
                                / real("38926432130826240000"))
                            ))));

        const complex phic2 = phic_prime(lat, dlon, e);

        return a * FE(e) * KahanSumComplex({
            phic2,
            a1 * sin(real(2) * phic2),
            a2 * sin(real(4) * phic2),
            a3 * sin(real(6) * phic2),
            a4 * sin(real(8) * phic2),
            a5 * sin(real(10) * phic2),
            a6 * sin(real(12) * phic2),
            a7 * sin(real(14) * phic2),
            a8 * sin(real(16) * phic2)
            });
    }

    // ========================
    // Series expansion of the complex variable ��,
    // following Guo et al. (2020), Eqs. (33)�C(35).
    // ========================
    inline complex zeta_by_series(
        const real& lat,   // geodetic latitude ��  (radian)
        const real& dlon,  // longitude difference ���� (radian)
        const real& e      // eccentricity
    )
    {

        real f1 =
            n * (real(3) / real(2)
                + n * (-(real(2) / real(3))
                    + n * (-(real(47) / real(48))
                        + n * (real(293) / real(180)
                            + n * (-(real(241) / real(1440))
                                + n * (-(real(72029) / real(37800))
                                    + n * (real(7021093) / real(3225600)
                                        + n * (real(5196481) / real(50803200)
                                            + n * (-(real(5589756763) / real(2032128000))
                                                + n * (real(144495378439) / real(50295168000)
                                                    + (real(23493339827) / real(357654528000)
                                                        - (real(16946124585611453) * n) / real(5178390497280000)
                                                        ) * n)
                                                )))))))));

        real f2 =
            n2 * (real(73) / real(48)
                + n * (-(real(19) / real(15))
                    + n * (-(real(3427) / real(1440))
                        + n * (real(3139) / real(630)
                            + n * (-(real(81547) / real(276480))
                                + n * (-(real(5357593) / real(604800))
                                    + n * (real(348016423) / real(34836480)
                                        + n * (real(16334396651) / real(4191264000)
                                            + n * (-(real(5904215001151) / real(292626432000))
                                                + n * (real(8464800462667) / real(523069747200)
                                                    + (real(11927070144293257) * n)
                                                    / real(976396861440000)
                                                    ))))))))));

        real f3 =
            n * n2 * (real(177) / real(80)
                + n * (-(real(1121) / real(420))
                    + n * (-(real(144841) / real(26880))
                        + n * (real(365357) / real(25920)
                            + n * (-(real(3427253) / real(3225600))
                                + n * (-(real(524932337) / real(15966720))
                                    + n * (real(250475028407) / real(6386688000)
                                        + n * (real(32001944628151) / real(1307674368000)
                                            + n * (-(real(35179075437235) / real(334764638208))
                                                + (real(79764215987478299) * n)
                                                / real(1098446469120000)
                                                )))))))));

        real f4 =
            n2 * n2 * (real(603793) / real(161280)
                + n * (-(real(14843) / real(2520))
                    + n * (-(real(12470017) / real(1036800))
                        + n * (real(16018067) / real(415800)
                            + n * (-(real(38515416901) / real(7664025600))
                                + n * (-(real(854069449301) / real(7783776000))
                                    + n * (real(746882145607061) / real(5230697472000)
                                        + (real(8881679261197) / real(81729648000)
                                            - (real("521253157744144403927") * n)
                                            / real(1124809184378880000)) * n)
                                    ))))));

        real f5 =
            n * n2 * n2 * (real(555379) / real(80640)
                + n * (-(real(3803159) / real(285120))
                    + n * (-(real(568876163) / real(21288960))
                        + n * (real(64225156139) / real(622702080)
                            + n * (-(real("1530009883783") / real("69742632960"))
                                + n * (-(real("34535876327371") / real("100590336000"))
                                    + n * (real("165518819343014383")
                                        / real("334764638208000")
                                        + (real("12187695184261805489") * n)
                                        / real("29877743960064000")
                                        )))))));

        real f6 =
            n2 * n2 * n2 * (real("4266870481") / real("319334400")
                + n * (-(real("885241627") / real("28828800"))
                    + n * (-(real("3440458049657") / real("58118860800"))
                        + n * (real("4944888487843") / real("18162144000")
                            + n * (-(real("28703478621825563")
                                / real("334764638208000"))
                                + n * (-(real("365642728287701363")
                                    / real("355687428096000"))
                                    + (real("16551865255439290261") * n)
                                    / real("10042939146240000")
                                    ))))));

        real f7 =
            n * n2 * n2 * n2 * (real("37217872147") / real("1383782400")
                + n * (-(real("44517464099") / real("622702080"))
                    + n * (-(real("260485711260583")
                        / real("1992646656000"))
                        + n * (real("18069405280267709")
                            / real("25406244864000")
                            + (-(real("50019232785926189")
                                / real("162599967129600"))
                                - (real("172609118976892835759") * n)
                                / real("57926238289920000")
                                ) * n
                            ))));

        real f8 =
            n2 * n2 * n2 * n2 * (real("41377942693441") / real("743921418240")
                + n * (-(real("69084529305097") / real("411675264000"))
                    + n * (-(real("31460438137870067")
                        / real("109442285568000"))
                        + (real("19458484323000157")
                            / real("10559470521600")
                            - (real("40348724876115364341937") * n)
                            / real("38926432130826240000")
                            ) * n
                        )));

        const complex phic2 = phic_prime(lat, dlon, e);

        return KahanSumComplex({
            phic2,
            f1 * sin(real(2) * phic2),
            f2 * sin(real(4) * phic2),
            f3 * sin(real(6) * phic2),
            f4 * sin(real(8) * phic2),
            f5 * sin(real(10) * phic2),
            f6 * sin(real(12) * phic2),
            f7 * sin(real(14) * phic2),
            f8 * sin(real(16) * phic2)
            });      
    }

    // ========================
    // Gauss�CKr��ger projection based on the nome-q series expansion.
    // ========================
    inline complex GK_q_series(
        const real& lat,   // geodetic latitude ��  (radian)
        const real& dlon,  // longitude difference ���� (radian)
        const real& e      // eccentricity
    )
    {               
        const real q = exp(-PI * ellint_1(sqrt(real(1) - e * e)) / ellint_1(e));
        const real q2 = q * q;
        const real q3 = q * q2;
        const real q4 = q2 * q2;

        real p1 = -q / (real(1) - q2);
        real p2 = q2 / (real(1) - q4);
        real p3 = -q3 / (real(1) - q2 * q4);
        real p4 = q4 / (real(1) - q4 * q4);
        real p5 = -q * q4 / (real(1) - q2 * q4 * q4);
        real p6 = q2 * q4 / (real(1) - q4 * q4 * q4);
        real p7 = -q3 * q4 / (real(1) - q2 * q4 * q4 * q4);
        real p8 = q4 * q4 / (real(1) - q4 * q4 * q4 * q4);

        const complex zeta = zeta_by_series(lat, dlon, e);

        return a * FE(e) * (zeta + real(4) * 
            KahanSumComplex({
             p1 * sin(real(2) * zeta),
             p2 * sin(real(4) * zeta),
             p3 * sin(real(6) * zeta),
             p4 * sin(real(8) * zeta),
             p5 * sin(real(10) * zeta),
             p6 * sin(real(12) * zeta),
             p7 * sin(real(14) * zeta),
             p8 * sin(real(16) * zeta)
            }) / (FK(e) * FE(e)));
    }

    // ========================
    // Scale factor of the GK projection at a given point.
    // ========================
    inline real scale(real lat, real u, real v, real e)
    {
        const real e2 = e * e;
        const real kp = sqrt(real(1) - e2);

        const real factor1 = sqrt(real(1) - e2 * sin(lat) * sin(lat)) / cos(lat);
        const real factor2 = sqrt(real(1) - sn(e, u) * sn(e, u) * dn(ep, v) * dn(ep, v));
        const real factor3 = sqrt(dn(e, u) * dn(e, u) + dn(ep, v) * dn(ep, v) - real(1));

        return (factor1 * factor2 / factor3);
    }

    // ========================
    // Meridian convergence (grid convergence angle) of the GK projection.
    // ========================
    inline real convergence(real lat, real u, real v, real e)
    {
        const real e2 = e * e;
        const real kp = sqrt(real(1) - e2);

        const real value = -(real(1) - e2) * sd(e, u) * nc(e, u) * sd(ep, v) * cn(ep, v);
        return atan2(value, real(1));
    }

}// namespace GK_proj
  
 
